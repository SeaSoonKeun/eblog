![](https://raw.githubusercontent.com/SeaSoonKeun/Picture/main/Blog_Pic/20210430221710.png)

![](https://raw.githubusercontent.com/SeaSoonKeun/Picture/main/Blog_Pic/20210430222029.png)

redis基于spring的api

https://docs.spring.io/spring-data/redis/docs/2.5.0/reference/html/#reference

