---
title: "Algolia评论系统"
date: 2021-04-21T17:30:02+08:00
draft: false
author: "SeaSoonKeun"
description: "Algolia评论系统"
tags: ["github","PicGo","图床"]
categories: ["工具"]
toc:
  auto: true

lightgallery: true

---

## Algolia 端
### 注册algolia免费账号

### 创建索引

### 记录API Keys